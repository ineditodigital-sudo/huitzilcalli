@foreach($promotions as $k => $promotion)
<tr>
    <td>{{ $k + 1 }}</td>
    <td>
        @if($promotion->image)
            <img src="{{ $promotion->image }}" alt="{{ $promotion->title }}" class="size-50px img-fit">
        @else
            <span>-</span>
        @endif
    </td>
    <td>{{ $promotion->title }}</td>
    <td>{{ Str::limit($promotion->description, 50) }}</td>
    <td>
        <div class="form-check form-switch">
            <input class="form-check-input" type="checkbox" onchange="changeStatus({{ $promotion->id }}, this)" @if($promotion->active == 1) checked @endif>
        </div>
    </td>
    <td class="text-end">
        <button class="btn btn-edit btn-icon rounded-circle btn-xs" onclick="editPromotion({{ $promotion->id }})" title="{{ __('Editar') }}">
            <i class="uil uil-edit fs-5"></i>
        </button>
        <button class="btn btn-delete btn-icon rounded-circle btn-xs" onclick="deletePromotion({{ $promotion->id }})" title="{{ __('Eliminar') }}">
            <i class="uil uil-trash fs-5"></i>
        </button>
    </td>
</tr>
@endforeach
